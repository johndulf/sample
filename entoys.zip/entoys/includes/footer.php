<script src="js/vue.3.js"></script>
<script src="js/axios.js"></script>
<?php echo $app; ?>
</body>
</html>